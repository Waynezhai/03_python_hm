#!/usr/bin/env python
#-*- coding:utf8 -*-
################################################################# 
# FileName: receive_message.py
# Author: Wayne_zhy
# Mail: zhyzhaihuiyan@163.com
# Created Time: 2019-04-25 06:49:49
# Last Modified: 2019-04-25 07:02:49
################################################################# 

def receive():
    return "这是来自 100xx 的消息!" 
