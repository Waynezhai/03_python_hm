#!/usr/bin/env python
#-*- coding:utf8 -*-
################################################################# 
# FileName: send_message.py
# Author: Wayne_zhy
# Mail: zhyzhaihuiyan@163.com
# Created Time: 2019-04-25 06:49:09
# Last Modified: 2019-04-25 07:00:39
################################################################# 

def send(text):
    print "正在发送消息 %s" % text
